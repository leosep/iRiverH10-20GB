iRiver H10 20GB (H10 20GC) - original firmware package
======================================================

Contents
--------
System/H10_20GC.mi4
    Original firmware read from a working H10 20GB. Version 1.03.01.
    This is the file the player bootloader loads at startup.

System/Font/cjk12.fnt
    System font. Installed as \System\Font\cjk12.fnt.

recovery/burnkey/
    Files from the official iRiver update package (package version 2.51):
      - H10_20GC_image.mi4 : official 1.03.01 system image
      - H10_20GC.mi4       : BURN KEY loader for bootloader recovery
      - BL_H10_20GC.hex    : encrypted bootloader
      - firmware.inf       : original manifest with install paths
    ADVANCED RECOVERY ONLY. Do not install these as normal firmware.

Recommended installation
------------------------
1. Connect the H10 in Emergency Connect (UMS) mode:
   - 20GB: press RESET with a paperclip, connect USB, then hold "O"
     while powering on until "Emergency Connect..." appears.
   - The player appears as a normal disk labelled H10.
2. Open H10 Firmware Manager, select the drive and click "Install firmware".
3. The app creates \System and \System\Font when they are missing,
   so it also works on a freshly formatted drive.
4. Safely eject the player and power it on.

If Rockbox is installed
-----------------------
Rockbox renames the original firmware to \System\OF.mi4 and installs its own
bootloader (signature "RBBL" at offset 0x1F8) as \System\H10_20GC.mi4.
The app detects this, creates a backup and can restore the original firmware,
optionally removing the .rockbox folder.

Legal notice
------------
The firmware is the property of iRiver/Reigncom. It is distributed only for
recovering and preserving H10 players. Use it at your own risk.